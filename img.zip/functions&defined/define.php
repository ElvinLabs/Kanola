<?php

define("HOST","127.0.0.1");
define("DBNAME","Kanola");
define("UNAME","root");
define("PW","root");


//$conn = mysqli_connect("localhost","kanolalk_admin","kanola@123","kanolalk_Kanola");
/* ERROR Massages*/
define("WRITIING_ERROR" , "writing_error");
define("NOTFILL","All Field Requered");


# image uploading
define("ROAD_IMG","roads/images/");



# auto & heavy machinary
define("AUTO","auto/");
define("AUTO_IMG","auto/images");

define("MACHINERY","heavy/");
define("MACHINERY_IMG","heavy/images");











?>